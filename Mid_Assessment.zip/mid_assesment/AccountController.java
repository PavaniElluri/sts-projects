package com.example.spring.controller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.spring.bean.Account;

import jakarta.validation.Valid;

@RestController

public class AccountController {

    private Map<Integer, Account> accountMap = new HashMap<>();

    // a) Save Account
    @PostMapping("/save")
    //public String saveAccount(@Valid @RequestBody Account account) {
        //accountMap.put(account.getAccNum(), account);
        //return "Account saved successfully";
    //}
    
    public String saveAccount(@Valid @RequestBody Account account) {
        
        if (account.getBalance() <= 0) {
            throw new ArithmeticException("Balance must be positive");
        }

        accountMap.put(account.getAccNum(), account);
        return "Account saved successfully";
    }

    // b) Get Account by Account Number
    @GetMapping("/get/{accNum}")
    public Account getAccount(@Valid @PathVariable int accNum) {
        return accountMap.get(accNum);
    }

    
   /* @GetMapping("/branch/{branchId}")
    public List<Account> getAccountByBranchId(@PathVariable String branchId) {
        List<Account> result = new ArrayList<>();
         
        for (Account account : accountMap.values()) {
            if (branchId.equals(account.getBranchId())) {
                result.add(account);
            }
        }
        
        return result;
   */ 
    //below by java8
@GetMapping("/branch/{branchId}")
public List<Account> getAccountByBranchId(@PathVariable String branchId) {
    return accountMap.values().stream()  
            .filter(account -> branchId.equals(account.getBranchId()))  
            .collect(Collectors.toList());  
}
    
}
    
    
    


