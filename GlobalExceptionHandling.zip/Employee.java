package com.example.SpringValidation.bean;

import org.hibernate.validator.constraints.Length;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class Employee {
	@NotNull
	@Min(value=1,message="give proper emp")
	@Max(value=2500,message="emp num shoulb be less than 25k")
	private int empno;
	
	@NotNull
	@Size(min=4,max=20,message="give propername")
	private String ename;
	

	
	private int sal;
	
	@Size(min=10,max=15,message="give proper ph num")
	private String phoneNumber;
	
	@NotEmpty
	@Size(min=10,max=15,message="give propername")
	private String addr;
	
	@Email(message="give proper email")
	private String email;
	
	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
}
	