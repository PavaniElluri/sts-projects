package com.example.SpringValidation.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandling {
	
	@ExceptionHandler(exception = NullPointerException.class)
	public ResponseEntity<Map<String,String>>handleNullPointerException
	(NullPointerException ne){
		Map<String,String> map=new HashMap<>();
		map.put("errorcode","101");
		map.put("errormessage","there is some null pointer exception");
		map.put("details",ne.getMessage());
		return new ResponseEntity<>(map,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	@ExceptionHandler(exception = NumberFormatException.class)
	public ResponseEntity<Map<String,String>>handleNumberFormatException
	(NumberFormatException ne){
		Map<String,String> map=new HashMap<>();
		map.put("errorcode","101");
		map.put("errormessage","do not give zero values");
		map.put("details",ne.getMessage());
		return new ResponseEntity<>(map,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(exception = ArithmeticException.class)
	public ResponseEntity<Map<String,String>>handleArithmeticException
	(ArithmeticException ne){
		Map<String,String> map=new HashMap<>();
		map.put("errorcode","101");
		map.put("errormessage","do not give zero for input2");
		map.put("details",ne.getMessage());
		return new ResponseEntity<>(map,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(exception = MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String,String>>handleBeanObject(MethodArgumentNotValidException me){
		BindingResult br=me.getBindingResult();
		//which is having field name field error
		Map<String,String> map=new HashMap<>();
		/*List<FieldError> list=br.getFieldErrors();
		for(FieldError er:list) {
			String field=er.getField();
			String messaage=er.getDefaultMessage();
			map.put(field, messaage);
		}*/
		br.getFieldErrors().forEach(x->map.put(x.getField(), x.getDefaultMessage()));
		return new ResponseEntity<>(map,HttpStatus.PARTIAL_CONTENT);
		
		
	}
	
}
		
		

		
		
	


