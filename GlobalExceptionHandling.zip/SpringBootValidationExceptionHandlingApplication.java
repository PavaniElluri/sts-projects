package com.example.SpringValidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootValidationExceptionHandlingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootValidationExceptionHandlingApplication.class, args);
	}

}
