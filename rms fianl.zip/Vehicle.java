package com.example.spring.bean;

import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

public class Vehicle {
	@Size(min=5,max=10,message="enter properly")
	private String vehicleId;
	@Size(min=5,max=20,message="enter properly")
	private String vehicleModel;
	@Positive
	private int seatPerCost;
	@Size(min=5,max=10,message="enter properly")
	private String ownerName;
	@Size(min=10,max=15,message="enter properly")
	private String phoneNumber;
	public String getVehicleId() {
		return vehicleId;
	}
	public void setVehicleId(String vehicleId) {
		this.vehicleId = vehicleId;
	}
	public String getVehicleModel() {
		return vehicleModel;
	}
	public void setVehicleModel(String vehicleModel) {
		this.vehicleModel = vehicleModel;
	}
	public int getSeatPerCost() {
		return seatPerCost;
	}
	public void setSeatPerCost(int seatPerCost) {
		this.seatPerCost = seatPerCost;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

}
