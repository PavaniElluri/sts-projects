package com.example.spring.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.spring.bean.Vehicle;

public class VehicleController {
	private Map<Integer,Vehicle>maps=new HashMap<>();
	@PostMapping("/save")
	public String meth1(@RequestBody Vehicle veh) {
		maps.put(veh.getSeatPerCost(),veh);
		return "data saved";
		
	}
	@GetMapping("/get/{vehicleId}")
	public List <Vehicle> meth2(@PathVariable String vehicleId) {
		List<Vehicle> result=new ArrayList<>();
		for(Vehicle veh:maps.values()) {
			if(vehicleId.equals(veh.getVehicleId())) {
				result.add(veh);
			}
	}
		return result;
}
	@GetMapping("/get/{ownerName}")
	public List<Vehicle> meth3(@PathVariable String ownerName){
		return maps.values()
				   .stream()
				   .filter(owner->ownerName.equals(owner.getOwnerName()))
				   .collect(Collectors.toList());
	}
}

